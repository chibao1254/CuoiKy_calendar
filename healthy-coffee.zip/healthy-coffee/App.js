import React from 'react';
import { Text, SafeAreaView, StyleSheet } from 'react-native';
import { Card } from 'react-native-paper';
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Thông tin cá nhân
      </Text>
      <Text style={styles.paragraph}>
        Họ và Tên: Nguyễn chí bảo
      
        Số điện thoại: 0945426303
      
        Mã số sinh viên: 220501040
      
        Email: 220501040@student.bdu.edu.vn
      
        Sở thích: Chơi điện tử, nghe nhạc, xem video giải trí,...
      </Text>
      <Card> 
        <AssetExample />
      </Card>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  }
});